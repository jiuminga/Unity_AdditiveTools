﻿
public class SD_CompilationUnit : SD_NameSpace
{
    public override SymbolDefinition AddDeclaration(SymbolDeclaration symbol)
    {
        return base.AddDeclaration(symbol);
    }

    public override void RemoveDeclaration(SymbolDeclaration symbol)
    {
        base.RemoveDeclaration(symbol);
    }
}
