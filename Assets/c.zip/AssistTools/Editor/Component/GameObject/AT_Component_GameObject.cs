﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

[UnityShell(Command ="gols")]
[UnityShell(Command ="gocd")]
[UnityShell(Command = "gorm")]
public class AT_Component_GameObject : AT_Component_Base
{
}
